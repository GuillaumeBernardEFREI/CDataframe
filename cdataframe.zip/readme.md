Voici le premier rendu de notre projet de CDataframe.
L'objectif dans le futur sera de realiser un Cdataframe pour des types de variables divers. (pas forcement des INT)
https://github.com/Samu7l/CDataFrame