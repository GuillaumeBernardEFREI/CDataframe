# Projet CDataframe - S2

Group members

Guillaume BERNARD - @GuillaumeBernardEFREI - https://github.com/GuillaumeBernardEFREI

Samuel MOLLIERE - @Samu7l - https://github.com/Samu7l

Link of the project : https://github.com/GuillaumeBernardEFREI/CDataframe

## Description of the project

The project goals was to implement a structure made up of a set of column,
called aCDataframe.

### Files and folder
- main.c
- cdataframe.c/.h
- column.c/.h
- sort.c/.h
- list.c/.h


### Functionalities
1. Create a dataframe
2. Display the dataframe
3. Basic operations (display/add/insert/delete a column/row)

How to execute the code ?
Instructions: Run the main,w hen you execute the program a menu displays all the features available.
To execute a feature input the integer linked to it according to the instructions of menu.

despite  a lot of hours spend on this project we couldnt finish it before the deadline (mainly because I was really sick) but we will finish for the presentation 

For this project, we decided to work on All data types, which was very difficult to work with.
We also created double-linked list for our CDataframe. Unfortunately, we only manage to create
and display the basic functionalities.


