#include <stdio.h>
#include "column.h"
#include <stddef.h>
int main() {

    COLUMN * col= create_column(INT,"text");
    int val=2;
    insert_value(col,&val);
    val=3;
    insert_value(col,&val);
    print_col(col);
    //printf("%s", col->title);

    return 0;
}
